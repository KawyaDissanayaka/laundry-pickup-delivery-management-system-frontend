export const mockEmployees = [
    { id: 'EMP-001', name: 'Kawya Dissanayaka', role: 'Operations Manager', email: 'kawya@laundrygo.com', phone: '077 890 1234', salary: 150000, status: 'Active' },
    { id: 'EMP-002', name: 'Shanilka Lakshan', role: 'Lead Specialist', email: 'shanilka@laundrygo.com', phone: '076 543 2109', salary: 135000, status: 'Active' },
    { id: 'EMP-003', name: 'Nipuni Navodya', role: 'Customer Relations', email: 'nipuni@laundrygo.com', phone: '075 678 9012', salary: 110000, status: 'Active' },
    { id: 'EMP-004', name: 'Nimal Perera', role: 'Quality Control', email: 'nimal@laundrygo.com', phone: '071 234 5678', salary: 105000, status: 'Active' },
    { id: 'EMP-005', name: 'Sanduni Fernando', role: 'Washer', email: 'sanduni@laundrygo.com', phone: '070 123 4567', salary: 96000, status: 'Active' },
    { id: 'EMP-006', name: 'Chamika Silva', role: 'Washer', email: 'chamika@laundrygo.com', phone: '077 345 6789', salary: 96000, status: 'On Leave' },
];


